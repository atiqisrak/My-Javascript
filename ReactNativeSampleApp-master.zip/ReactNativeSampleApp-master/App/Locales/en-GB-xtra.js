// Programatic GB translations - do not add directly
// Use npm run translation:backfill

export default {};