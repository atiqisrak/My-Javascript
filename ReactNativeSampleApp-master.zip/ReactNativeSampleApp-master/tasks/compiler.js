require('babel-core/register');

module.exports = require('./_compiler').default;
